% Signal_Addition.m
% This program generates two signals and adds them together.

t = 0:0.1:6;
t1 = 0:0.1:3;
zz = cos(2*t1);

sig1 = zeros(1, length(t));
sig1(1:length(t1)) = zz;

t2 = 3.1:0.1:6;
zzz = cos(6*t2);

sig2 = zeros(1, length(t));
sig2(end-length(t2)+1:end) = zzz;

sig3 = sig1 + sig2;

figure
subplot(3,1,1);
stem(t, sig1);
title('x(t)');
xlabel("t");
ylabel("signal1");

subplot(3,1,2);
stem(t, sig2);
title('y(t)');
xlabel("t");
ylabel("signal2");

subplot(3,1,3);
stem(t, sig3);
title('z(t) = x(t) + y(t)');
xlabel("t");
ylabel("signal3");
