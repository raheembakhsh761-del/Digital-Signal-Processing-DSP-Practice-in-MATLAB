% Sinc_Function_Plot.m
% This program plots the sinc function.

x = linspace(-10, 10, 100);
y = sinc(x);

figure;
plot(x, y, 'LineWidth', 1.5);
title('Graph of sinc(x)');
xlabel('t');
ylabel('y(t)');
grid on;
