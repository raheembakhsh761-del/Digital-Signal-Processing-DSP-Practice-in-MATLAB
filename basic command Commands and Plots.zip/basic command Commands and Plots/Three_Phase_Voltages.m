% Three_Phase_Voltages.m
% This program plots three-phase voltages (440 V, 50 Hz)
% with 120° phase difference between each phase.

% Given parameters
amp = 440;           % Amplitude (Volts)
f = 50;              % Frequency (Hz)
t = 0:0.0001:0.04;   % Time vector
a = 0;               % Phase A angle
b = -120 * pi/180;   % Phase B angle in radians
c = -240 * pi/180;   % Phase C angle in radians

% Generating three-phase voltages
Va = amp * sin(2 * pi * f * t + a);
Vb = amp * sin(2 * pi * f * t + b);
Vc = amp * sin(2 * pi * f * t + c);

% Plotting
figure;
plot(t, Va, 'r', 'LineWidth', 1.5, 'DisplayName', 'Phase A');
hold on;
plot(t, Vb, 'g', 'LineWidth', 1.5, 'DisplayName', 'Phase B');
plot(t, Vc, 'b', 'LineWidth', 1.5, 'DisplayName', 'Phase C');
hold off;

xlabel('Time (s)');
ylabel('Voltage (V)');
title('Three-Phase Voltages (440 V, 50 Hz)');
legend show;
grid on;
