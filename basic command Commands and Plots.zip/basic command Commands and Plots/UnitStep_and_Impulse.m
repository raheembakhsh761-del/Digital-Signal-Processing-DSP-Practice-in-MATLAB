% UnitStep_and_Impulse.m
% This program generates and plots the unit step signal u[n]
% and the unit impulse signal δ[n] in terms of u[n].

n = -5:5;

% Unit step signal
u = (n >= 0);

% Unit impulse signal defined using step function
delta = u - [0 u(1:end-1)];

% Plotting
figure;

subplot(2,1,1);
stem(n, u, 'LineWidth', 1.5);
title('Unit Step Signal u[n]');
xlabel('n');
ylabel('u[n]');
grid on;

subplot(2,1,2);
stem(n, delta, 'LineWidth', 1.5);
title('Unit Impulse Signal \delta[n] in terms of u[n]');
xlabel('n');
ylabel('\delta[n]');
grid on;
