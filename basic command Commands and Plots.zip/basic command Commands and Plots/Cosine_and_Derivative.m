% Cosine_and_Derivative.m
% This program plots a cosine function and its derivative (-sin(t)).

syms t
x = cos(t);
y = diff(x);

figure;

% Plot of cosine function
subplot(1,2,1);
fplot(x, [-2, 2], 'LineWidth', 1.5);
title('Graph of cos(t)');
xlabel('t');
ylabel('x(t)');
grid on;

% Plot of derivative (-sin(t))
subplot(1,2,2);
fplot(y, [-2, 2], 'LineWidth', 1.5);
title('Graph of derivative (-sin(t))');
xlabel('t');
ylabel('y(t)');
grid on;
