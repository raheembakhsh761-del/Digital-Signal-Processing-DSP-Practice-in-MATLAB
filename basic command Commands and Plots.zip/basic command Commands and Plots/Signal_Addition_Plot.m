% Signal_Addition_Plot.m
% This program generates two cosine signals and adds them together.

t = 0:0.1:6;

% First signal: cos(2t) from t = 0 to 3
t1 = 0:0.1:3;
zz = cos(2 * t1);
sig1 = zeros(1, length(t));
sig1(1:length(t1)) = zz;

% Second signal: cos(6t) from t = 3.1 to 6
t2 = 3.1:0.1:6;
zzz = cos(6 * t2);
sig2 = zeros(1, length(t));
sig2(end - length(t2) + 1:end) = zzz;

% Combined signal
sig3 = sig1 + sig2;

% Plot all signals
figure
subplot(3,1,1);
plot(t, sig1, 'LineWidth', 1.5);
title('x(t)');
xlabel('t');
ylabel('signal1');
grid on;

subplot(3,1,2);
plot(t, sig2, 'LineWidth', 1.5);
title('y(t)');
xlabel('t');
ylabel('signal2');
grid on;

subplot(3,1,3);
plot(t, sig3, 'LineWidth', 1.5);
title('z(t) = x(t) + y(t)');
xlabel('t');
ylabel('signal3');
grid on;
