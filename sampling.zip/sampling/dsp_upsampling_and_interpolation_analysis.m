
clc; clear; close all; 

Fs = 16000;        
N  = 128;           
t  = (-N/2:N/2-1)/Fs; 
a  = 4000; 
x = a * sinc(a * t).^2; 

X = fftshift(fft(ifftshift(x), N)); 
f = (-N/2:N/2-1) * (Fs/N); 
Xmag = abs(X) / max(abs(X)); 

% Plot original 
figure; 
plot(t*1000, x, 'LineWidth', 1.2); 
title('Original Time Domain Signal'); 
xlabel('Time (ms)');  
ylabel('Amplitude');  
grid on; 

figure; 
plot(f, Xmag, 'LineWidth', 1.2); 
xlim([-8000 8000]); 
title('Original Frequency Domain'); 
xlabel('Frequency (Hz)');  
ylabel('Normalized Magnitude');  
grid on; 

% Upsampling 
L = 2;                             
xu = upsample(x, L);                
Fs_up = Fs * L;                    
N_up = length(xu); 

XU = fftshift(fft(ifftshift(xu), N_up)); 
f_up = (-N_up/2:N_up/2-1) * (Fs_up/N_up); 
XU_mag = abs(XU) / max(abs(XU)); 
t_up = (0:length(xu)-1)/Fs_up - mean((0:length(xu)-1)/Fs_up); 

figure; 
plot(t_up, xu, 'LineWidth', 1.2); 
title(sprintf('Upsampled Time Domain Signal (L = %d)', L)); 
xlabel('Time (ms)'); 
ylabel('Amplitude'); 
grid on; 

figure; 
plot(f_up, XU_mag, 'LineWidth', 1.2); 
xlim([-16000 16000]); 
title(sprintf('Upsampled Frequency Domain Magnitude (L = %d)', L)); 
xlabel('Frequency (Hz)'); 
ylabel('Normalized Magnitude'); 
grid on; 

% Interpolation
xi = interp(x, L);    
Xi = fftshift(fft(ifftshift(xi), length(xi))); 
fi = (-length(xi)/2:length(xi)/2-1) * (Fs_up/length(xi)); 
Xi_mag = abs(Xi) / max(abs(Xi)); 

figure; 
plot(fi, Xi_mag, 'LineWidth', 1.2); 
xlim([-16000 16000]); 
title('Interpolated (Filtered) Frequency Domain'); 
xlabel('Frequency (Hz)'); 
ylabel('Normalized Magnitude'); 
grid on;
