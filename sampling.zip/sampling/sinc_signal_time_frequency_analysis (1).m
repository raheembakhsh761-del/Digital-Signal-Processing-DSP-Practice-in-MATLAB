%Raheem Bakhsh 
%NUM-BSEE-2023-10 
Fs = 16000;         
N = 128;           
t = (-N/2:N/2-1)/Fs; 
a = 4000; 
x = a * sinc(a * t).^2; 
X = fftshift(fft(x, N)); 
f = (-N/2:N/2-1) * (Fs/N); 
Xmag = abs(X) / max(abs(X)); 
 
figure; 
plot(t, x, 'LineWidth', 1.2); 
title('Time Domain Signal (short segment)'); 
xlabel('Time (ms)'); 
ylabel('Amplitude'); 
grid on; 
 
figure; 
plot(f, Xmag, 'LineWidth', 1.2);    
xlim([-8000 8000]); 
title('Frequency Domain Magnitude'); 
xlabel('Frequency (Hz)'); 
ylabel('Normalized Magnitude'); 
grid on; 