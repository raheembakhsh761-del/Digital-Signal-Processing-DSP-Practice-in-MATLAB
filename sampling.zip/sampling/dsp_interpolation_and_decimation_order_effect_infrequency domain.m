
clc; clear; close all;

Fs = 16000;        % Sampling frequency
N  = 128;          % Number of samples
t  = (-N/2:N/2-1)/Fs; 
a  = 4000;         % Signal parameter

x = a * (sinc(a * t)).^2;   % Original signal

L = 2;   % Interpolation factor
M = 3;   % Decimation factor

% ----- Case 1: Interpolation then Decimation -----
x_up = interp(x, L);       
y1 = decimate(x_up, M);    
Fs1 = Fs * (L/M);         
N1 = length(y1); 
Y1 = fftshift(fft(y1, N1)); 
f1 = (-N1/2:N1/2-1)*(Fs1/N1); 
Y1mag = abs(Y1)/max(abs(Y1)); 

% ----- Case 2: Decimation then Interpolation -----
x_down = decimate(x, M);   
y2 = interp(x_down, L);    
Fs2 = Fs * (L/M);       

N2 = length(y2); 
Y2 = fftshift(fft(y2, N2)); 
f2 = (-N2/2:N2/2-1)*(Fs2/N2); 
Y2mag = abs(Y2)/max(abs(Y2)); 

% ----- Plot frequency-domain results -----
figure;
subplot(3,1,1);
X = fftshift(fft(x, N)); 
f = (-N/2:N/2-1)*(Fs/N); 
x_or = abs(X)/max(abs(X));   
plot(f, x_or, 'LineWidth', 1.2); 
title('Original Signal Spectrum');
xlabel('Frequency (Hz)'); 
ylabel('Magnitude'); 
xlim([-8000 8000]); 
grid on;

subplot(3,1,2);
plot(f1, Y1mag, 'LineWidth', 1.2);
title('Interpolation → Decimation (L=2, M=3)');
xlabel('Frequency (Hz)');  
ylabel('Magnitude');  
grid on;  
xlim([-8000 8000]);

subplot(3,1,3);
plot(f2, Y2mag, 'LineWidth', 1.2);
title('Decimation → Interpolation (M=3, L=2)');
xlabel('Frequency (Hz)');  
ylabel('Magnitude');
grid on; 
xlim([-8000 8000]);
